<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "¡Servidor funcionando!";
?>



<?php
require 'config/database.php'; // Asegúrate de que este archivo esté en la misma carpeta

try {
    // Realiza una consulta a la tabla 'students'
    $stmt = $pdo->query("SELECT * FROM students"); // Cambia 'students' si el nombre es diferente
    $rows = $stmt->fetchAll();
    
    // Itera sobre los resultados y muestra los nombres de los estudiantes
    foreach ($rows as $row) {
        echo $row['name'] . "<br>"; // Asegúrate de que 'name' sea una columna válida
    }
} catch (\PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

