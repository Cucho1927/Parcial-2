<?php
require_once __DIR__ . '/../config/database.php'; // Cambia la ruta aquí
require_once __DIR__ . '/../models/Student.php'; // Cambia la ruta aquí

class StudentController {
    private $studentModel;

    public function __construct($pdo) {
        $this->studentModel = new Student($pdo);
    }

    public function index() {
        $students = $this->studentModel->getStudents();
        include __DIR__ . '/../views/student_view.php'; // Cambia la ruta aquí
    }
}
?>

