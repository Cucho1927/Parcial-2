<?php
// Configurar el error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir la configuración de la base de datos
require_once 'config/database.php';

// Crear la conexión
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Define el ID del curso del cual deseas obtener las notas
$course_id = "1"; // Cambia esto al ID de curso que necesites

// Consulta para obtener las notas del curso específico
$sql = "SELECT g.id AS grade_id, e.student_id, gt.name AS grade_type, g.grade, gt.weight 
        FROM grades g 
        JOIN enrollment e ON g.enrollment_id = e.id 
        JOIN grade_type gt ON g.grade_type_id = gt.id 
        WHERE e.course_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $course_id); // Bind del parámetro de curso (entero)
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notas del Curso</title>
    <style>
        /* Aquí puedes añadir tus estilos CSS como antes */
    </style>
</head>
<body>

    <h1>Notas del Curso ID: <?php echo $course_id; ?></h1>

    <?php
    // Verificar si hay resultados
    if ($result->num_rows > 0) {
        // Mostrar los resultados en una tabla
        echo "<table>
                <tr>
                    <th>ID de Nota</th>
                    <th>ID de Estudiante</th>
                    <th>Tipo de Nota</th>
                    <th>Nota</th>
                    <th>Ponderación</th>
                </tr>";

        // Salida de cada fila
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["grade_id"] . "</td>
                    <td>" . $row["student_id"] . "</td>
                    <td>" . $row["grade_type"] . "</td>
                    <td>" . $row["grade"] . "</td>
                    <td>" . $row["weight"] . "</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No se encontraron notas para este curso.</p>";
    }

    // Cerrar la conexión
    $stmt->close();
    $conn->close();
    ?>

</body>
</html>
