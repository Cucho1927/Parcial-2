<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/controllers/StudentController.php';

$controller = new StudentController($pdo);
$controller->index(); // Llama al método del controlador para mostrar la vista
?>

