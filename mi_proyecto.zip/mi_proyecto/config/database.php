<?php
// Configuración de la base de datos
$db_host = 'localhost'; // Servidor de la base de datos
$db_user = 'root'; // Usuario de la base de datos (por defecto en XAMPP)
$db_password = ''; // Contraseña (deja vacío si no tienes)
$db_name = 'school'; // Cambia esto al nombre de tu base de datos
?>

