<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Estudiantes</title>
</head>
<body>
    <h1>Lista de Estudiantes</h1>
    <ul>
        <?php foreach ($students as $student): ?>
            <li><?php echo htmlspecialchars($student['name']); ?></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
